/**
 * @file BKEM.h
 * @brief General construction of the Boneh-Gentry-Waters 
 * broadcast key encapsulation scheme 
 *
 * BKEM is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * BKEM is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with BKEM.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * Oliver Guenther
 * mail@oliverguenther.de
 *
 * 
 * BKEM.h
*/

#ifndef H_BKEM
#define H_BKEM

#include <string.h>
#include <pbc/pbc.h>

/**
  @typedef Global broadcast system parameters
 */
 
//#define MAX_m  16            // Max channels
//#define MAX_n  64            // Max subscriber
//#define MAX_SET MAX_n        // Here, Sets are  Users in Channel Sj

#define Max_N 2048		// Total Number of users	
#define LogMax_N 11		// Length of identity string or l= Log Max_n (base 2)
#define Subs_Num 64

 
typedef struct bkem_global_params_s {
	pairing_t pairing;
	int N;
	
}* bkem_global_params_t;

/**
 * @typedef Public Key
 * Contains generator g, 2B-2 elements g[i] and A elements v[i]
 */
typedef struct pubkey_s {
    element_t g; 		// 1st generator: g
    element_t g0; 		// element g0=g
    element_t h; 		// element h from G
    element_t Q1;		// element Q1 from G
    element_t Q2;		// element Q2 from G
    element_t r1;		// element r1 from Z_q^{*}
    element_t r2;		// element r2 from Z_q^{*}
    element_t beta; 		// element beta from Z_q^{*}
    element_t pub1; 		// element pub1=g^{r1}
    element_t pub2; 		// element pub1=g^{r2}
    element_t b_[Max_N];	// element beta^{i}
    element_t h_b_[Max_N];	// element h^{beta}^i 
    element_t e_g_h;		// element e(g,h) 
    element_t g_beta;		// element g^{beta}
    element_t s;		// element s
    element_t rid_[Max_N];	 // element real identity of the user i
    element_t pid_[Max_N][2];	 // element pseud-identity of the user i
    element_t pub1_s; 		 // element (pub_1)^s
    element_t hash_pub1_s; 	 // element hash of (pub_1)^s
    element_t h1_pid1[Max_N];   // element h_1(pid_{i,1})
    element_t h2_pid12[Max_N];  // element h_2(pid_{i,1}||pid_{i,2}||T_i)
    element_t hash_rid_[Max_N]; // element hash of rid_i
    element_t hash_pid[Max_N];  // element hash of pid_i
    element_t b_hash_rid[Max_N];// element (beta+H(rid))
    element_t prod_b_hash_rid;  // element product of (beta+H(rid))
    element_t prod_b_hash_rid1; // element product of (beta+H(rid)) without i-th term 
    element_t prod_hash_rid;    // element product of H(rid)  
    element_t prod_hash_rid1;   // element product of H(rid) without i-th term
    element_t P_S_b_[Max_N];    // element p_{j,S}(beta)
    element_t h_P_j_S_b[Max_N]; // element h^{p_{j,S}(beta)}
    
        
}* pubkey_t;

/**
* Variable for Secret key 
*/

typedef struct bkem_secret_key_s 
{
	/** Private key of user s */
	element_t d[Max_N][2];
}* bkem_secret_key_t;

/***
*
*
*/	
typedef struct
{
    int useri,channelj;  // User user_i  subscribe to chanel channel_j
} ID;


/**
 * @typedef broadcast system instance
 */
typedef struct bkem_system_s {
	pubkey_t PK;
	element_t SK[Max_N][2];
	element_t BK_ID_[Max_N];
	element_t BKK_ID_[Max_N];
	element_t h[Max_N];
	element_t k;
	element_t K[Max_N];
	element_t hash2_k;	
	element_t m0;
	element_t CT_0;
	element_t CTT_0;
	element_t CT_1;
	element_t CT_2;
	element_t IK0;
	element_t IK1[Max_N];
		
	
	/** Private key of user s */
/*	element_t t[LogMax_N];
	element_t z[Max_N];
	element_t d[MAX_m][MAX_n][3];
	element_t hash_store[MAX_m][MAX_n];
	element_t all_hash_sum;
	element_t channel_hash_sum[MAX_m];
	element_t check;
	element_t C_1_x[MAX_m];
	element_t M_x[MAX_m];
	element_t C_22_x[MAX_m];
	element_t C_2_x[MAX_m];
	

*/	
}* bkem_system_t;


/**
 * @typedef Keypair (HDR, K) [A+1, 1] elements
 */


typedef struct header_s 
{
    element_t C_00;
  /*  element_t C_1_x[MAX_m];
    element_t C_2_x[MAX_m];
    element_t theta_x[MAX_m];
    element_t Gamma_x[MAX_m];
 */   
}* header_t;


typedef struct kpair_s {
    element_t *HR;
}* kpair_t;

typedef struct keypair_s {
    element_t *HDR;
    element_t K;
}* keypair_t;



/**
 * @brief Free a keypair_t
 */
void free_pubkey(pubkey_t pk, bkem_global_params_t gbs);


/**
 * @brief Free a bkem_system_t
 */
void free_bkem_system(bkem_system_t sys, bkem_global_params_t gbs);


/**
 * @brief Free a global_broadcast_params_t
 */
void free_global_params(bkem_global_params_t gbs);



/**
 * Setup global broadcast system parameters
 * @param[out] gps bkem_global_params_t pointer
 * @param[in] params Pairing Type paramters as string
 * @param[in] n number of users in the system
 */
void setup_global_system(bkem_global_params_t *gps, const char *params, int n);


/**
 * Setup broadcast key encapsulation system
 * @param[out] sys bkem_system_t pointer
 * @param[in] gps bkem_global_params_t pointer
 */
 
void setup(bkem_system_t *sys, bkem_global_params_t gps);


/**
 * Output encryption Keypair
 * @param[out] keypair pointer to encryption pair output
 * @param[in] S receiver array [indices of participating users]
 * @param[in] num_recip Number of elements in S
 * @param[in] sys Broadcast encryption parameters
 */
 
 
//void get_encryption_key(keypair_t *key, int *S, int num_recip, bkem_system_t sys, bkem_global_params_t gps);
//void grouptoken(keypair_t *key, int *S, int num_recip, bkem_system_t sys, bkem_global_params_t gps);



void get_enc_key(bkem_system_t sys, bkem_global_params_t gps);




/**
 * Output decryption Key
 * @param[out] K decryption key pointer
 * @param[in] gps global system parameters
 * @param[in] S receivers [indices of participating users]
 * @param[in] num_recip Number of elements in S
 * @param[in] i index of user
 * @param[in] d_i private key of user i
 * @param[in] HDR header
 * @param[in] PK public key
 */
 
 
void get_decryption_key(bkem_global_params_t gbs, bkem_system_t sys, pubkey_t PK);


#endif

#include <string.h>
#include <stdio.h>
#include <math.h>
#include <gmp.h>
#include "bkem.h"
#include <time.h>
clock_t setup_time, keygen_time, enc_time, dec_time;
void setup_global_system(bkem_global_params_t *gps, const char *pstr, int N) {
    
    bkem_global_params_t params;
    params = pbc_malloc(sizeof(struct bkem_global_params_s));

    params->N = N;
    
    pairing_init_set_str(params->pairing, pstr);

    *gps = params;
}


void setup(bkem_system_t *sys, bkem_global_params_t gps) 
{
    setup_time = clock();
    
    // 
    bkem_system_t gbs;
    bkem_secret_key_t sk;
    gbs = pbc_malloc(sizeof(struct bkem_system_s));
    gbs->PK = pbc_malloc(sizeof(struct pubkey_s));

    // ---------------------------------Choose random generator g --------------------------------------------
    element_init_G1(gbs->PK->g, gps->pairing);
    element_random(gbs->PK->g);
    //element_printf("g = %B\n\n", gbs->PK->g);
    
    // ---------------------------------Choose random generator h --------------------------------------------
    element_init_G1(gbs->PK->h, gps->pairing);
    element_random(gbs->PK->h);
    
    // ---------------------------------Choose random generator Q_1 --------------------------------------------
    element_init_G1(gbs->PK->Q1, gps->pairing);
    element_random(gbs->PK->Q1);
    
    // ---------------------------------Choose random generator Q_2 --------------------------------------------
    element_init_G1(gbs->PK->Q2, gps->pairing);
    element_random(gbs->PK->Q2);
    
    // ---------------------------------Choose random r1 --------------------------------------------
    element_init_Zr(gbs->PK->r1, gps->pairing);
    element_random(gbs->PK->r1);
    
    // ---------------------------------Choose random r2 --------------------------------------------
    element_init_Zr(gbs->PK->r2, gps->pairing);
    element_random(gbs->PK->r2);
    
    // ---------------------------------Choose random beta --------------------------------------------
    element_init_Zr(gbs->PK->beta, gps->pairing);
    element_random(gbs->PK->beta);
    
    // ---------------------------------Compute pub1 --------------------------------------------
    element_init_G1(gbs->PK->pub1, gps->pairing);
    element_pow_zn(gbs->PK->pub1, gbs->PK->g, gbs->PK->r1);
    //element_printf("pub1 = %B\n\n", gbs->PK->pub1);
    
    // ---------------------------------Compute pub2 --------------------------------------------
    element_init_G1(gbs->PK->pub2, gps->pairing);
    element_pow_zn(gbs->PK->pub2, gbs->PK->g, gbs->PK->r2);
    //element_printf("pub2 = %B\n\n", gbs->PK->pub2);
    
    // ---------------------------------Compute g0 --------------------------------------------
    element_init_G1(gbs->PK->g0, gps->pairing);
    element_set(gbs->PK->g0, gbs->PK->g);
    //element_printf("g0 = %B\n\n", gbs->PK->g0);
    
    // ---------------------------------Compute b_[Max_N] --------------------------------------------
    element_t temp;
    element_init_Zr(temp, gps->pairing);
    element_set1(temp);
    for(int i=0;i<Max_N;i++){
    element_init_Zr(gbs->PK->b_[i], gps->pairing);
    element_mul(temp,gbs->PK->beta,temp); 
    //element_printf("beta^{%d} = %B\n\n", i,temp);
    element_init_G1(gbs->PK->h_b_[i], gps->pairing);
    element_pow_zn(gbs->PK->h_b_[i], gbs->PK->h, temp);
    //element_printf("h^{beta^{%d}} = %B\n\n", i,gbs->PK->h_b_[i]);
    }
    
    // ---------------------------------Compute e(g,h) --------------------------------------------
    element_init_GT(gbs->PK->e_g_h, gps->pairing);
    pairing_apply(gbs->PK->e_g_h,gbs->PK->g, gbs->PK->h,gps->pairing);
    //element_printf("e(g,h) = %B\n\n", gbs->PK->e_g_h);
    
    // ---------------------------------Compute g^{beta} --------------------------------------------
    element_init_G1(gbs->PK->g_beta, gps->pairing);
    element_pow_zn(gbs->PK->g_beta, gbs->PK->g, gbs->PK->beta);
    //element_printf("g^{beta}= %B\n\n", gbs->PK->g_beta);
    
    // ---------------------------------Compute s --------------------------------------------
    element_init_Zr(gbs->PK->s, gps->pairing);
    element_random(gbs->PK->s);
    //element_printf("s= %B\n\n", gbs->PK->s);
    
    // ---------------------------------Compute H(pub1 ^s) --------------------------------------------
    element_init_G1(gbs->PK->hash_pub1_s, gps->pairing);
    element_init_G1(gbs->PK->pub1_s, gps->pairing);
    element_pow_zn(gbs->PK->pub1_s, gbs->PK->g, gbs->PK->s);
    //element_printf("pub_1^s= %B\n\n", gbs->PK->pub1_s);
    element_random(gbs->PK->hash_pub1_s);
    //element_printf("H(pub_1^s)= %B\n\n", gbs->PK->hash_pub1_s);
    
    
    // ---------------------------------Compute real identity rid_i and pseudo-identity--------------------------------
    for(int i=0;i<Max_N;i++){
    element_init_Zr(gbs->PK->rid_[i], gps->pairing);
    element_random(gbs->PK->rid_[i]); 
    //element_printf("real identity of the user %d = %B\n\n", i,gbs->PK->rid_[i]);
    element_init_Zr(gbs->PK->hash_rid_[i], gps->pairing);
    element_random(gbs->PK->hash_rid_[i]); 
    //element_printf("The hash of the real identity of the user %d = %B\n\n", i, gbs->PK->hash_rid_[i]);
    element_init_G1(gbs->PK->pid_[i][0], gps->pairing);
    element_pow_zn(gbs->PK->pid_[i][0], gbs->PK->g, gbs->PK->s); 
    //element_printf("pid_{%d,1} = %B\n\n", i,gbs->PK->pid_[i][0]);
    element_init_Zr(gbs->PK->pid_[i][1], gps->pairing);
    element_add(gbs->PK->pid_[i][1], gbs->PK->rid_[i], gbs->PK->hash_pub1_s);
    //element_printf("pid_{%d,2} = %B\n\n", i,gbs->PK->pid_[i][1]);
    element_init_Zr(gbs->PK->hash_pid[i], gps->pairing);
    element_random(gbs->PK->hash_pid[i]);
    //element_printf("The hash of pid_{%d}=(pid_{%d,1},pid_{%d,2}) = %B\n\n", i,i,i,gbs->PK->hash_pid[i]);
    } 
        
    
/*
   // -------------------------------Compute the component of MPK ---------------------------------------------
   gbs->PK->mpk_i = pbc_malloc( 5 * sizeof(element_t));
   int size_of_MPK=(Max_N+LogMax_N+5) * sizeof(element_t);		// 
   //element_printf("size_of_MPK = %d in bytes\n\n", size_of_MPK);
    
   // element_printf("Compute the component of MPK\n");
	   
*/   


    setup_time = clock() - setup_time;
    double time_taken0 = ((double)setup_time)/CLOCKS_PER_SEC; // in seconds 
    printf("Setup took %f seconds to execute \n\n", time_taken0);  
    
   
    //int size_of_MSK=3 * sizeof(element_t);
    //element_printf("size_of_MSK = %d in bytes\n\n", size_of_MSK);
   
   //------------------ MPK and MSK generation is done ----------------------------------------------------------------
  
 	

   // -------------------- To Compute private keys of users --------------------------------------------------------

    keygen_time = clock();
    int user=7;
    element_t t11, t12, t13, t14;
    element_init_G1(gbs->SK[user][0], gps->pairing);
    element_pow_zn(gbs->SK[user][0], gbs->PK->pid_[user][0], gbs->PK->r1); 
    //element_printf("SK_[%d,1] = %B\n\n", user,gbs->SK[user][0]);
    element_init_Zr(gbs->PK->h1_pid1[user], gps->pairing);
    element_random(gbs->PK->h1_pid1[user]);
    element_init_Zr(gbs->PK->h2_pid12[user], gps->pairing);
    element_random(gbs->PK->h2_pid12[user]);
    element_init_Zr(t11, gps->pairing);
    element_mul(t11,gbs->PK->h2_pid12[user],gbs->PK->r2);
    element_init_G1(t12, gps->pairing);
    element_pow_zn(t12,gbs->PK->Q1,t11);
    element_init_G1(t13, gps->pairing);
    element_pow_zn(t13,gbs->PK->Q2,gbs->PK->h1_pid1[user]);
    element_init_G1(gbs->SK[user][1], gps->pairing);
    element_mul(gbs->SK[user][1], t12, t13); 
    //element_printf("SK_[%d,2] = %B\n\n", user,gbs->SK[user][1]);
    element_init_Zr(t14, gps->pairing);
    element_add(t14,gbs->PK->beta,gbs->PK->hash_rid_[user]);
    //element_printf("beta+H(rid[%d]) = %B\n\n", user,t14);
    element_invert(t14,t14);
    //element_printf("inverse of [beta+H(rid[%d])] = %B\n\n", user,t14);
    element_init_G1(gbs->BK_ID_[user], gps->pairing);
    element_pow_zn(gbs->BK_ID_[user],gbs->PK->g,t14);
    //element_printf("broadcast key BK_ID_[%d] = %B\n\n", user,gbs->BK_ID_[user]);
            
    
    
    keygen_time = clock() - keygen_time;
    double time_taken1 = ((double)keygen_time)/CLOCKS_PER_SEC; // in seconds 
    printf("KeyGen took %f seconds to execute \n\n", time_taken1); 


    *sys = gbs;
 
    
    //----------------------------Key Gen is done ----------------
}



//=================================Encryption =============================================




void get_enc_key( bkem_system_t gbs, bkem_global_params_t gps) 
{
     enc_time=clock();
     
     //--------------------Generate IBBE Ciphertext ----------------------
     element_t t21, t22, t23, t24, t25, t26, t27, t28, t29, t211, t212, t213, t214, t215, t216, t217, t218, t219;
     element_t r;
     element_init_Zr(r, gps->pairing);
     element_random(r);
     element_init_GT(gbs->m0, gps->pairing);
     element_random(gbs->m0);
     element_init_GT(t21, gps->pairing);
     element_pow_zn(t21,gbs->PK->e_g_h,r);
     element_init_GT(gbs->CT_0, gps->pairing);		
     element_mul(gbs->CT_0, gbs->m0, t21);
     //element_printf("CT_0= %B\n\n", gbs->CT_0);
     element_init_Zr(t22, gps->pairing);
     element_neg(t22,r);
     element_init_G1(gbs->CT_1, gps->pairing);		
     element_pow_zn(gbs->CT_1, gbs->PK->g0, t22);
     //element_printf("CT_1= %B\n\n", gbs->CT_1);
     
     element_init_Zr(gbs->PK->prod_b_hash_rid, gps->pairing);
     element_set1(gbs->PK->prod_b_hash_rid);
     element_init_Zr(gbs->PK->prod_hash_rid, gps->pairing);
     element_set1(gbs->PK->prod_hash_rid);
     for(int i=0;i<Subs_Num;i++){
     element_init_Zr(gbs->PK->b_hash_rid[i], gps->pairing);
     element_add(gbs->PK->b_hash_rid[i],gbs->PK->beta,gbs->PK->hash_rid_[i]);
     element_mul(gbs->PK->prod_b_hash_rid,gbs->PK->prod_b_hash_rid,gbs->PK->b_hash_rid[i]);
     element_mul(gbs->PK->prod_hash_rid,gbs->PK->prod_hash_rid,gbs->PK->hash_rid_[i]);     
     }
     
     element_init_Zr(t25, gps->pairing);
     element_mul(t25,gbs->PK->prod_b_hash_rid,r);
     element_init_G1(gbs->CT_2, gps->pairing);		
     element_pow_zn(gbs->CT_2, gbs->PK->h, t25);
     //element_printf("CT_2= %B\n\n", gbs->CT_2); 
         
     //------------------------Intermediate Key Generation---------------------------
     //element_init_Zr(t26, gps->pairing);
     //element_set1(t26);
     for(int j=0; j<Subs_Num; j++){ 

     element_init_Zr(t27, gps->pairing);
     element_invert(t27,gbs->PK->b_hash_rid[j]);
     element_init_G1(gbs->BK_ID_[j], gps->pairing);
     element_pow_zn(gbs->BK_ID_[j],gbs->PK->g,t27);
     //element_printf("broadcast key BK_ID_[%d] = %B\n\n", j ,gbs->BK_ID_[j]);
     
/*     element_init_Zr(t28, gps->pairing);
     element_set1(t28);
     element_init_Zr(t213, gps->pairing);
     element_init_Zr(t214, gps->pairing);
     element_set1(t213);

     for(int i=0;i<Subs_Num;i++){
     element_mul(t28,t28,gbs->PK->hash_rid_[i]);
     element_add(t214,gbs->PK->beta,gbs->PK->hash_rid_[i]);
     element_mul(t213,t213,t214);       	
     }
*/
     element_init_Zr(gbs->PK->prod_b_hash_rid1, gps->pairing);
     element_div(gbs->PK->prod_b_hash_rid1,gbs->PK->prod_b_hash_rid,gbs->PK->b_hash_rid[j]);
     element_init_Zr(gbs->PK->prod_hash_rid1, gps->pairing);
     element_div(gbs->PK->prod_hash_rid1,gbs->PK->prod_hash_rid,gbs->PK->hash_rid_[j]);
     element_init_GT(gbs->k, gps->pairing);
     element_random(gbs->k);
     element_init_G1(gbs->hash2_k, gps->pairing);
     element_random(gbs->hash2_k);
     element_init_G1(t211, gps->pairing);
     element_pow_zn(t211,gbs->hash2_k,gbs->PK->prod_b_hash_rid1);
     element_init_G1(gbs->BKK_ID_[j], gps->pairing);
     element_mul(gbs->BKK_ID_[j],gbs->BK_ID_[j],t211);   
     //element_printf("broadcast key BK'_ID_[%d] = %B\n\n", j ,gbs->BKK_ID_[j]);
     element_init_GT(gbs->IK0, gps->pairing);
     element_mul(gbs->IK0,gbs->k,t21);
     //element_printf("IK0 = %B\n\n", gbs->IK0);
     element_init_G1(gbs->IK1[j], gps->pairing);
     element_init_Zr(t212, gps->pairing);
     element_mul(t212,gbs->PK->b_hash_rid[j],r);
     element_pow_zn(gbs->IK1[j],gbs->PK->h,t212); 
     //element_printf("IK1[%d] = %B\n\n", j ,gbs->IK1[j]);
     
     //--------------------Transformed Ciphertext Generation ----------------------------
     element_init_Zr(t215, gps->pairing);
     element_init_Zr(gbs->PK->P_S_b_[j], gps->pairing);     
     element_sub(t215,gbs->PK->prod_b_hash_rid1,gbs->PK->prod_b_hash_rid1);
     element_div(gbs->PK->P_S_b_[j],t215,gbs->PK->beta);
     element_init_G1(gbs->PK->h_P_j_S_b[j], gps->pairing);
     element_pow_zn(gbs->PK->h_P_j_S_b[j],gbs->PK->g,gbs->PK->P_S_b_[j]);
     element_init_GT(t216, gps->pairing);
     pairing_apply(t216,gbs->CT_1, gbs->PK->h_P_j_S_b[j],gps->pairing);
     element_init_GT(t217, gps->pairing);
     pairing_apply(t217, gbs->BKK_ID_[j], gbs->CT_2, gps->pairing);
     element_init_GT(t218, gps->pairing);
     element_mul(t218, t216, t217);
     element_init_Zr(t219, gps->pairing);
     element_invert(t219, gbs->PK->prod_hash_rid1);     
     element_init_GT(gbs->K[j], gps->pairing);
     element_pow_zn(gbs->K[j],t218,t219);   
     //element_printf("The value of K corresponding to %d = %B\n\n", j ,gbs->K[j]); 
     element_init_GT(gbs->CTT_0, gps->pairing);
     element_div(gbs->CTT_0,gbs->CTT_0,gbs->K[j]);   
     //element_printf("The value of K corresponding to %d = %B\n\n", j ,gbs->K[j]); 
     }
     
    

     enc_time = clock() - enc_time; 
     double time_taken2 = ((double)enc_time)/(CLOCKS_PER_SEC); // in seconds 
     printf("Encryption algorithm took %f seconds to execute for %d users \n\n", time_taken2, Subs_Num); 
       
             	
}




void get_decryption_key(bkem_global_params_t gps, bkem_system_t gbs, pubkey_t PK)
 {
 	dec_time=clock();
 	int user=7;
 	element_t t31, t32, t33, t34, t35, t36, t37, t38, t39,t391;
 	element_init_GT(t31, gps->pairing);
     	pairing_apply(t31,gbs->CT_1, gbs->PK->h_P_j_S_b[user],gps->pairing);
     	element_init_GT(t32, gps->pairing);
     	pairing_apply(t32, gbs->BK_ID_[user], gbs->CT_2, gps->pairing);
     	element_init_GT(t33, gps->pairing);
     	element_mul(t33, t31, t32);
     	element_init_Zr(t34, gps->pairing);
     	element_invert(t34, gbs->PK->prod_hash_rid1); 
     	element_init_GT(t35, gps->pairing);
     	element_pow_zn(t35, t33, t34); 	//m_{0}^{'}=e(g,h)^r
     	element_init_GT(t36, gps->pairing);
     	element_div(t36, gbs->CT_0, t35); 
     	//element_printf(" m_0= %B\n\n",t36);
     	//element_printf(" m_0= %B\n\n",gbs->m0);
     	
     	//--------------(2)------------------------------
     	element_init_GT(t37, gps->pairing);
     	pairing_apply(t37,gbs->BK_ID_[user],gbs->IK1[user],gps->pairing);
     	element_init_GT(t38, gps->pairing);
     	element_div(t38,gbs->IK0,t37);
     	//element_printf(" k= %B\n\n",t38);
     	//element_printf(" k= %B\n\n",gbs->k);
     	element_init_GT(t39, gps->pairing);
     	
     	pairing_apply(t39,gbs->hash2_k,gbs->hash2_k,gps->pairing);
     	element_init_GT(t391, gps->pairing);
     	element_mul(t391,gbs->CTT_0,t39);
     	//element_printf(" m_0= %B\n\n",t39);
     	//element_printf(" m_0= %B\n\n",gbs->m0); 	
 	

 			
 	dec_time = clock() - dec_time; 
   	double time_taken3 = ((double)dec_time)/(CLOCKS_PER_SEC); // in seconds 
  	printf("Decryption algorithm took %f seconds to execute for a subscribed user\n\n", time_taken3);
  	
  	//element_printf("The plaintext is %B\n\n",gbs->M);
 	//element_printf("The recover message is %B\n\n",Guess_M); 
}


/*void free_global_params(bkem_global_params_t gbs) {
    if (!gbs)
        return;

    pairing_clear(gbs->pairing);
    free(gbs);
}
*/
/*void free_pubkey(pubkey_t pk, bkem_global_params_t gbs) {
    if (!pk)
        return;

    element_clear(pk->g);

    int i;
    for (i = 0; i <= gbs->N; ++i) {
        element_clear(pk->g_i[i]);
    }

    //for (i = 0; i < gbs->A; ++i) {
       // element_clear(pk->v_i[0]);
    //}

}
*/
/*void free_bkem_system(bkem_system_t sys, bkem_global_params_t gbs) {
    if (!sys)
        return;

    free_pubkey(sys->PK, gbs);

    int i;
    /*for (i = 0; i < gbs->N; ++i) {
        element_clear(sys->d_i[i]);
    }*/
//}
